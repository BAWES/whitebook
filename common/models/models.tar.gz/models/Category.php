<?php

namespace backend\models;

use yii\helpers\ArrayHelper;
use Yii;
use yii\helpers\Url;

/**
 * This is the model class for table "whitebook_category".
 *
 * @property string $category_id
 * @property string $parent_category_id
 * @property string $category_name
 * @property string $category_allow_sale
 * @property integer $created_by
 * @property integer $modified_by
 * @property string $created_datetime
 * @property string $modified_datetime
 * @property string $trash
 *
 * @property AdvertCategory[] $advertCategories
 * @property Category $parentCategory
 * @property Category[] $categories
 * @property VendorItem[] $vendorItems
 * @property VendorItemRequest[] $vendorItemRequests
 */
class Category extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'whitebook_category';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
			['category_name','categoryvalidation'],
            [['parent_category_id', 'created_by', 'modified_by'], 'integer'],
            [['category_allow_sale', 'trash'], 'string'],
            [['category_name', 'category_allow_sale'], 'required'],
            [['created_datetime', 'modified_datetime'], 'safe'],
            [['category_name'], 'string', 'max' => 128]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'category_id' => 'Category ID',
            'parent_category_id' => 'Parent Category',
            'category_name' => 'Category name',
            'category_allow_sale' => 'Category Allow status',
            'created_by' => 'Created By',
            'modified_by' => 'Modified By',
            'created_datetime' => 'Created Datetime',
            'modified_datetime' => 'Modified Datetime',
            'trash' => 'Trash',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAdvertCategories()
    {
        return $this->hasMany(AdvertCategory::className(), ['category_id' => 'category_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getParentCategory()
    {
        return $this->hasOne(Category::className(), ['category_id' => 'parent_category_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCategories()
    {
        return $this->hasMany(Category::className(), ['parent_category_id' => 'category_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getVendorItems()
    {
        return $this->hasMany(VendorItem::className(), ['category_id' => 'category_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getVendorItemRequests()
    {
        return $this->hasMany(VendorItemRequest::className(), ['category_id' => 'category_id']);
    }
    
    public static function statusImageurl($sale)
	{			
		if($sale == 'yes')		
		return \Yii::$app->params['appImageUrl'].'active.png';
		return \Yii::$app->params['appImageUrl'].'inactive.png';
	}
	
	public static function categoryvalidation($attribute_name,$params)
	{
		if(!empty($this->category_name) ){
		$model = Category::find()->where(['category_name'=>$this->category_name])->one();
        if($model){
        $this->addError('category_name','Please enter a unique category name');
        }
		}
	}
	
	public static function loadcategoryname()
	{       
			$category= Category::find()
			->where(['!=', 'category_status', 'Deactive'])
			->where(['!=', 'trash', 'Deleted'])
			->where(['parent_category_id' => null])
			->all();
			$category=ArrayHelper::map($category,'category_id','category_name');
			return $category;
	}	
	
	public static function loadcategory()
	{
		$categories=Category::find()->where(['category_allow_sale' => 'yes'])->all();			
		$category=ArrayHelper::map($categories,'category_id','category_name');
		return $category;
	}


}
