<?php

namespace backend\models;
use yii\helpers\ArrayHelper;
use Yii;
use yii\helpers\Url;

/**
 * This is the model class for table "whitebook_item_type".
 *
 * @property string $type_id
 * @property string $type_name
 * @property integer $created_by
 * @property integer $modified_by
 * @property string $created_datetime
 * @property string $modified_datetime
 * @property string $trash
 *
 * @property VendorItem[] $vendorItems
 */
class Itemtype extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'whitebook_item_type';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['type_name', 'created_by', 'modified_by', 'created_datetime', 'modified_datetime'], 'required'],
            [['created_by', 'modified_by'], 'integer'],
            [['created_datetime', 'modified_datetime'], 'safe'],
            [['trash'], 'string'],
            [['type_name'], 'string', 'max' => 100]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'type_id' => 'Type ID',
            'type_name' => '“sale”,”rentals”,”service”',
            'created_by' => 'Created By',
            'modified_by' => 'Modified By',
            'created_datetime' => 'Created Datetime',
            'modified_datetime' => 'Modified Datetime',
            'trash' => 'Trash',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getVendorItems()
    {
        return $this->hasMany(VendorItem::className(), ['type_id' => 'type_id']);
    }
    
    	    public static function loaditemtype()
	{       
			$itemtype= Itemtype::find()
			->where(['!=', 'trash', 'Deleted'])
			->all();
			$itemtype=ArrayHelper::map($itemtype,'type_id','type_name');
			return $itemtype;
	}	
	
	        public static function loadvendorname()
	{       
			$vendorname= Vendor::find()
			->where(['!=', 'trash', 'Deleted'])
			->all();
			$vendorname=ArrayHelper::map($vendorname,'vendor_id','vendor_name');
			return $vendorname;
	}	
}

