<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "{{%image_resize}}".
 *
 * @property integer $id
 * @property integer $logo_width
 * @property integer $logo_height
 * @property integer $favicon_width
 * @property integer $favicon_height
 * @property integer $noimage_width
 * @property integer $noimage_height
 * @property integer $created_by
 * @property integer $modified_by
 * @property string $created_datetime
 * @property string $modified_datetime
 * @property string $trash
 */
class Imageresize extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%image_resize}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['logo_width', 'logo_height', 'favicon_width', 'favicon_height', 'noimage_width', 'noimage_height', 'created_by', 'modified_by', 'created_datetime', 'modified_datetime'], 'required'],
            [['logo_width', 'logo_height', 'favicon_width', 'favicon_height', 'noimage_width', 'noimage_height', 'created_by', 'modified_by'], 'integer'],
            [['created_datetime', 'modified_datetime'], 'safe'],
            [['trash'], 'string']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'logo_width' => 'Logo Width',
            'logo_height' => 'Logo Height',
            'favicon_width' => 'Favicon Width',
            'favicon_height' => 'Favicon Height',
            'noimage_width' => 'Noimage Width',
            'noimage_height' => 'Noimage Height',
            'created_by' => 'Created By',
            'modified_by' => 'Modified By',
            'created_datetime' => 'Created Datetime',
            'modified_datetime' => 'Modified Datetime',
            'trash' => 'Trash',
        ];
    }
}
