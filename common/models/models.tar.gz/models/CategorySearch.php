<?php

namespace backend\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use backend\models\Category;
use backend\models\SubCategory;

/**
 * CategorySearch represents the model behind the search form about `backend\models\Category`.
 */
class CategorySearch extends Category
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['category_id', 'parent_category_id', 'created_by', 'modified_by'], 'integer'],
            [['category_name', 'category_allow_sale', 'created_datetime', 'modified_datetime', 'trash'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
		 $query = SubCategory::find()
        ->where(['!=', 'trash', 'Deleted'])
        ->andwhere(['parent_category_id' => null])
		->orderBy('category_id');
		 $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);			
        $this->load($params);

        if (!$this->validate()) {
           return $dataProvider;
        }
        $query->andFilterWhere(['parent_category_id' => NULL]);
        return $dataProvider;
    }
    
        public static function subcategory_search($params)
    {
        $query = SubCategory::find()
        ->where(['!=', 'trash', 'Deleted'])
        ->andwhere(['!=', 'parent_category_id', 'NULL'])
		->orderBy('category_id');
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            return $dataProvider;
        }

        $query->andFilterWhere(['like', 'category_name', $this->category_name]);
            //->andFilterWhere(['like', 'category_allow_sale', $this->category_allow_sale]);
           // ->andFilterWhere(['like', 'trash', $this->trash]);

        return $dataProvider;
    }
}
