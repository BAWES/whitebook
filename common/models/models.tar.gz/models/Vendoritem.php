<?php

namespace backend\models;

use Yii;
use yii\helpers\ArrayHelper;
/**
 * This is the model class for table "whitebook_vendor_item".
 *
 * @property string $item_id
 * @property string $type_id
 * @property string $vendor_id
 * @property string $category_id
 * @property string $item_name
 * @property string $item_description
 * @property string $item_additional_info
 * @property integer $item_amount_in_stock
 * @property integer $item_default_capacity
 * @property string $item_price_per_unit
 * @property string $item_customization_description
 * @property string $item_price_description
 * @property string $item_for_sale
 * @property integer $item_how_long_to_make
 * @property integer $item_minimum_quantity_to_order
 * @property string $item_archived
 * @property string $item_approved
 * @property integer $created_by
 * @property integer $modified_by
 * @property string $created_datetime
 * @property string $modified_datetime
 * @property string $trash
 *
 * @property CustomerCart[] $customerCarts
 * @property EventItemLink[] $eventItemLinks
 * @property FeatureGroupItem[] $featureGroupItems
 * @property PriorityItem[] $priorityItems
 * @property SuborderItemPurchase[] $suborderItemPurchases
 * @property ItemType $type
 * @property Vendor $vendor
 * @property Category $category
 * @property VendorItemCapacityException[] $vendorItemCapacityExceptions
 * @property VendorItemImage[] $vendorItemImages
 * @property VendorItemPricing[] $vendorItemPricings
 * @property VendorItemQuestion[] $vendorItemQuestions
 * @property VendorItemRequest[] $vendorItemRequests
 * @property VendorItemTheme[] $vendorItemThemes
 * @property Theme[] $themes
 */
class Vendoritem extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'whitebook_vendor_item';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            //[['type_id', 'vendor_id', 'category_id', 'item_description', 'item_additional_info', 'item_amount_in_stock', 'item_default_capacity', 'item_customization_description', 'item_price_description', 'item_how_long_to_make','item_archived','item_approved','item_minimum_quantity_to_order','item_name','item_for_sale','item_price_per_unit'], 'required'],
            [['type_id', 'vendor_id', 'category_id','subcategory_id', 'item_amount_in_stock', 'item_default_capacity', 'item_how_long_to_make', 'item_minimum_quantity_to_order', 'created_by', 'modified_by'], 'integer'],
            [['item_description', 'item_additional_info', 'item_customization_description', 'item_price_description', 'item_for_sale', 'item_archived', 'item_approved', 'trash'], 'string'],
            [['item_price_per_unit'], 'number'],
            [['created_datetime', 'modified_datetime'], 'safe'],
            [['item_name'], 'string', 'max' => 128]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'item_id' => 'Item ID',
            'type_id' => 'Item Type',
            'vendor_id' => 'Vendor ID',
            'category_id' => 'Category ID',
            'item_name' => 'Item Name',
            'item_description' => 'Item Description',
            'item_additional_info' => 'Item Additional Info',
            'item_amount_in_stock' => 'Amt deducted on per sale',
            'item_default_capacity' => 'Item Default Capacity',
            'item_price_per_unit' => 'Item Price per Unit',
            'item_customization_description' => 'Item Description',
            'item_price_description' => 'Item Price Description',
            'item_for_sale' => 'Item For Sale',
            'item_how_long_to_make' => 'No of days deliver',
            'item_minimum_quantity_to_order' => 'Item Minimum Quantity to Order',
            'item_archived' => 'Item Archieved',
            'item_approved' => 'Item Approved',
            'created_by' => 'Created By',
            'modified_by' => 'Modified By',
            'created_datetime' => 'Created Datetime',
            'modified_datetime' => 'Modified Datetime',
            'trash' => 'Trash',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCustomerCarts()
    {
        return $this->hasMany(CustomerCart::className(), ['item_id' => 'item_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getEventItemLinks()
    {
        return $this->hasMany(EventItemLink::className(), ['item_id' => 'item_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getFeatureGroupItems()
    {
        return $this->hasMany(FeatureGroupItem::className(), ['item_id' => 'item_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPriorityItems()
    {
        return $this->hasMany(PriorityItem::className(), ['item_id' => 'item_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSuborderItemPurchases()
    {
        return $this->hasMany(SuborderItemPurchase::className(), ['item_id' => 'item_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getType()
    {
        return $this->hasOne(ItemType::className(), ['type_id' => 'type_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getVendor()
    {
        return $this->hasOne(Vendor::className(), ['vendor_id' => 'vendor_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCategory()
    {
        return $this->hasOne(Category::className(), ['category_id' => 'category_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getVendorItemCapacityExceptions()
    {
        return $this->hasMany(VendorItemCapacityException::className(), ['item_id' => 'item_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getVendorItemImages()
    {
        return $this->hasMany(VendorItemImage::className(), ['item_id' => 'item_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getVendorItemPricings()
    {
        return $this->hasMany(VendorItemPricing::className(), ['item_id' => 'item_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getVendorItemQuestions()
    {
        return $this->hasMany(VendorItemQuestion::className(), ['item_id' => 'item_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getVendorItemRequests()
    {
        return $this->hasMany(VendorItemRequest::className(), ['item_id' => 'item_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getVendorItemThemes()
    {
        return $this->hasMany(VendorItemTheme::className(), ['item_id' => 'item_id']);
    }
    public static function getCategoryName($id)
    {		
		$model = Category::find()->where(['category_id'=>$id])->one();
        return $model->category_name;
    }
    
        public static function getVendorName($id)
    {		
		$model = Vendoritem::find()->where(['vendor_id'=>$id])->one();
        return $model->item_name;
    }
            public static function getItemType($id)
    {		
		$model = Itemtype::find()->where(['type_id'=>$id])->one();
        return $model->type_name;
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getThemes()
    {
        return $this->hasMany(Theme::className(), ['theme_id' => 'theme_id'])->viaTable('whitebook_vendor_item_theme', ['item_id' => 'item_id']);
    }
    
    public static function loadvendoritem()
	{       
			$city= Vendoritem::find()
			->where(['!=', 'item_status', 'Deactive'])
			->where(['!=', 'trash', 'Deleted'])
			->all();
			$city=ArrayHelper::map($city,'item_id','item_name');
			return $city;
	}
	 public static function statusImageurl($status)
	{			
		if($status == 'Active')		
		return \Yii::$app->params['appImageUrl'].'active.png';
		return \Yii::$app->params['appImageUrl'].'inactive.png';
	}	
	
	
    
}
