<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "whitebook_feature_group".
 *
 * @property string $group_id
 * @property string $group_name
 * @property integer $created_by
 * @property integer $modified_by
 * @property string $created_datetime
 * @property string $modified_datetime
 * @property string $trash
 *
 * @property FeatureGroupItem[] $featureGroupItems
 */
class Featuregroup extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'whitebook_feature_group';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['group_name',], 'required'],
            [['group_name',],'unique'],
            [['created_by', 'modified_by'], 'integer'],
            [['created_datetime', 'modified_datetime'], 'safe'],
            [['trash'], 'string'],
            [['group_name'], 'string', 'max' => 128]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'group_id' => 'Group ID',
            'group_name' => 'Group Name',
            'created_by' => 'Created By',
            'modified_by' => 'Modified By',
            'created_datetime' => 'Created Datetime',
            'modified_datetime' => 'Modified Datetime',
            'trash' => 'Trash',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getFeatureGroupItems()
    {
        return $this->hasMany(FeatureGroupItem::className(), ['group_id' => 'group_id']);
    }
    
        public static function statusImageurl($img_status)
	{			
		if($img_status == 'Active')		
		return \Yii::$app->urlManagerBackEnd->createAbsoluteUrl('themes/default/img/active.png');
		return \Yii::$app->urlManagerBackEnd->createAbsoluteUrl('themes/default/img/inactive.png');
	}
}
