<?php

namespace app\models;

use Yii;
use yii\web\UploadedFile;

/**
 * This is the model class for table "siteinfo".
 *
 * @property integer $id
 * @property string $app_name
 * @property string $app_desc
 * @property string $meta_keyword
 * @property string $meta_desc
 * @property string $email_id
 * @property string $phone_number
 * @property integer $site_location
 * @property string $site_copyright
 * @property string $site_logo
 * @property string $site_favicon
 * @property string $site_noimage
 */
class Siteinfo extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%siteinfo}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['app_name', 'app_desc', 'meta_keyword', 'meta_desc', 'email_id', 'site_location', 'site_copyright'], 'required'],
            [['app_name', 'app_desc', 'site_location','phone_number','meta_keyword', 'meta_desc', 'email_id', 'site_copyright'],'required', 'on' => 'update'],
            [['app_desc', 'meta_desc', 'google_analytics', 'live_script'], 'string'],                      
            [['site_logo', 'site_favicon','site_noimage'],'file','extensions' => ['png', 'jpg', 'jpeg']],
            [['app_name', 'facebook_key', 'facebook_secret_key'], 'string', 'max' => 100],
            [['meta_keyword'], 'string', 'max' => 250],
            [['email_id', 'site_noimage'], 'string', 'max' => 50],
            [['site_copyright', 'site_favicon'], 'string', 'max' => 200],
            [['facebook_share_url', 'twitter_share_url', 'google_share_url', 'linkedin_share_url'], 'string', 'max' => 150],
            /* Validation Rules */
            [['email_id'],'email'],
            ['phone_number','match', 'pattern' => '/^[0-9+ -]+$/','message' => 'Phone number accept only numbers and +,-']
        ];
    }
    
    public function scenarios()
    {
		$scenarios = parent::scenarios();        
        $scenarios['update'] = ['app_name', 'app_desc', 'site_location','phone_number','meta_keyword', 'meta_desc', 'email_id', 'site_copyright'];//Scenario Values Only Accepted
        return $scenarios;
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'app_name' => 'App Name',
            'app_desc' => 'App Desc',
            'meta_keyword' => 'Meta Keyword',
            'meta_desc' => 'Meta Desc',
            'email_id' => 'Email ID',
            'phone_number' => 'Phone Number',            
            'site_location' => 'Site Location',            
            'site_copyright' => 'Site Copyright',
            'site_logo' => 'Site Logo',            
            'site_favicon' => 'Site Favicon',
            'site_noimage' => 'Site Noimage',            
            'facebook_key' => 'Facebook Key'      
           
        ];
    }
    public static function logoUrl()
    {
		$model = Siteinfo::find()->all();
		foreach($model as $key=>$val)
		{
			 $logo = $val['site_logo'];
			 echo Yii::getAlias('@web/uploads/app_img').'/'.$logo;
		}
		
	}
	
	public static function faviconUrl()
    {
		$model = Siteinfo::find()->all();
		foreach($model as $key=>$val)
		{
			 $logo = $val['site_favicon'];
			 echo Yii::getAlias('@web/uploads/app_img').'/'.$logo;
		}
		
	}
}
