<?php

namespace backend\models;

use Yii;
use yii\helpers\Url;

/**
 * This is the model class for table "{{%advert_category}}".
 *
 * @property string $advert_id
 * @property string $category_id
 * @property string $advert_position
 * @property string $advert_code
 *
 * @property Category $category
 */
class Advertcategory extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%advert_category}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['category_id', 'advert_code','advert_position'], 'required'],
            [['category_id'], 'integer'],
            [['advert_position', 'advert_code'], 'string']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'advert_id' => 'Advertisement ID',
            'category_id' => 'Category Name',
            'advert_position' => 'Advertisement Position',
            'advert_code' => 'Advertisement Code',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public static function getCategory()
    {
        return $this->hasOne(Category::className(), ['category_id' => 'category_id']);
    }
    
    public static function statusImageurl($status)
	{			
		if($status == 'Unblock')		
		return \Yii::$app->urlManagerBackEnd->createAbsoluteUrl('theme/barebone/assets/img/active.png');
		return \Yii::$app->urlManagerBackEnd->createAbsoluteUrl('theme/barebone/assets/img/inactive.png');
	}
}
