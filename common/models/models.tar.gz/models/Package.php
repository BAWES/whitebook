<?php

namespace backend\models;

use Yii;
use yii\helpers\ArrayHelper;
/**
 * This is the model class for table "whitebook_package".
 *
 * @property string $package_id
 * @property string $package_name
 * @property integer $package_max_number_of_listings
 * @property string $package_sales_commission
 * @property string $package_pricing
 * @property integer $created_by
 * @property integer $modified_by
 * @property string $created_datetime
 * @property string $modified_datetime
 * @property string $trash
 *
 * @property Vendor[] $vendors
 */
class Package extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'whitebook_package';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['package_name','package_max_number_of_listings', 'package_sales_commission', 'package_pricing',], 'required'],
            [['package_max_number_of_listings', 'created_by', 'modified_by'], 'integer'],
            [['package_sales_commission', 'package_pricing'], 'number'],
            [['created_datetime', 'modified_datetime'], 'safe'],
            [['trash'], 'string'],
            [['package_name'], 'string', 'max' => 128]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'package_id' => 'Package ID',
            'package_name' => 'Package ',
            'package_max_number_of_listings' => 'Maximum no of List',
            'package_sales_commission' => 'Sales Commission',
            'package_pricing' => 'Pricing',
            'created_by' => 'Created By',
            'modified_by' => 'Modified By',
            'created_datetime' => 'Created Datetime',
            'modified_datetime' => 'Modified Datetime',
            'trash' => 'Trash',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getVendors()
    {
        return $this->hasMany(Vendor::className(), ['package_id' => 'package_id']);
    }
    
        public static function statusImageurl($img_status)
	{			
		if($img_status == 'Active')		
		return \Yii::$app->urlManagerBackEnd->createAbsoluteUrl('themes/default/img/active.png');
		return \Yii::$app->urlManagerBackEnd->createAbsoluteUrl('themes/default/img/inactive.png');
	}
	
		
	public static function loadpackage()
	{
		$packages=Package::find()->where(['package_status' => 'Active'])->all();			
		$package=ArrayHelper::map($packages,'package_id','package_name');
		return $package;
	}
	
	public static function PackageData($pack_id)
	{	
		$package_data= Package::find()->where(['package_id' => $pack_id,'package_status' => 'Active'])->all();	
		return $package_data;		
	}
	
	
	
}
