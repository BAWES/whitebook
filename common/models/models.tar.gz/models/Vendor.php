<?php

namespace backend\models;

use Yii;
use yii\base\NotSupportedException;
use yii\db\ActiveRecord;
use yii\behaviors\TimestampBehavior;
use yii\web\IdentityInterface;
use yii\db\BaseActiveRecord;
use yii\helpers\Security;
use backend\models\Role;
use yii\helpers\ArrayHelper;


/**
 * This is the model class for table "{{%vendor}}".
 *
 * @property string $vendor_id
 * @property string $package_id
 * @property string $image_id
 * @property string $vendor_name
 * @property string $vendor_brief
 * @property string $vendor_return_policy
 * @property string $vendor_public_email
 * @property string $vendor_public_phone
 * @property string $vendor_working_hours
 * @property string $vendor_contact_name
 * @property string $vendor_contact_email
 * @property string $vendor_contact_number
 * @property string $vendor_emergency_contact_name
 * @property string $vendor_emergency_contact_email
 * @property string $vendor_emergency_contact_number
 * @property string $vendor_website
 * @property string $package_start_date
 * @property string $package_end_date
 * @property string $vendor_delivery_charge
 * @property string $vendor_password
 * @property string $vendor_status
 * @property integer $created_by
 * @property integer $modified_by
 * @property string $created_datetime
 * @property string $modified_datetime
 * @property string $trash
 *
 * @property Suborder[] $suborders
 * @property Package $package
 * @property Image $image
 * @property VendorAddress[] $vendorAddresses
 * @property VendorBlockedDate[] $vendorBlockedDates
 * @property VendorDeliveryArea[] $vendorDeliveryAreas
 * @property VendorDeliveryTimeslot[] $vendorDeliveryTimeslots
 * @property VendorItem[] $vendorItems
 */
class Vendor extends \yii\db\ActiveRecord implements IdentityInterface
{
	public $auth_key;
	public $password_hash;
	public $password_reset_token;

   // private $_user = false;
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%vendor}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['package_id', 'image_id', 'vendor_brief', 'vendor_return_policy', 'vendor_public_email', 'vendor_public_phone', 'vendor_working_hours', 'package_start_date', 'package_end_date', 'vendor_delivery_charge', 'created_by', 'modified_by', 'created_datetime', 'modified_datetime'], 'required'],
            [['package_id', 'vendor_name','vendor_contact_email','vendor_password','vendor_contact_number','package_start_date', 'package_end_date','vendor_status'], 'required', 'on'=>'register'],
            [['package_id', 'image_id', 'created_by', 'modified_by'], 'integer'],
            [['vendor_brief', 'vendor_return_policy', 'vendor_working_hours', 'vendor_status', 'trash'], 'string'],
            [['package_start_date', 'package_end_date', 'created_datetime', 'modified_datetime'], 'safe'],           
			[['package_end_date'], 'default', 'value' => null],
            [['vendor_delivery_charge'], 'number'],
            [['vendor_password'], 'required', 'on' => 'change'],
            /* Validation Rules */
            [['vendor_contact_email'],'email'],
            [['vendor_name', 'vendor_public_email', 'vendor_public_phone', 'vendor_contact_name', 'vendor_contact_email', 'vendor_contact_number', 'vendor_emergency_contact_name', 'vendor_emergency_contact_email', 'vendor_emergency_contact_number', 'vendor_website'], 'string', 'max' => 128]
        ];
    }
    
    public function scenarios()
    {
		$scenarios = parent::scenarios();      
        $scenarios['register'] = ['vendor_name','vendor_contact_email','vendor_password','vendor_contact_number','vendor_status'];//Scenario Values Only Accepted
        $scenarios['change'] = ['vendor_password'];//Scenario Values Only Accepted
        return $scenarios;
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'vendor_id' => 'Vendor ID',
            'package_id' => 'Package Name',
            'image_id' => 'Image ID',
            'vendor_name' => 'Vendor Name',
            'vendor_brief' => 'Vendor Brief',
            'vendor_return_policy' => 'Vendor Return Policy',
            'vendor_public_email' => 'Vendor Public Email',
            'vendor_public_phone' => 'Vendor Public Phone',
            'vendor_working_hours' => 'Vendor Working Hours',
            'vendor_contact_name' => 'Vendor Contact Name',
            'vendor_contact_email' => 'Email',
            'vendor_contact_number' => 'Vendor Contact Number',
            'vendor_emergency_contact_name' => 'Vendor Emergency Contact Name',
            'vendor_emergency_contact_email' => 'Vendor Emergency Contact Email',
            'vendor_emergency_contact_number' => 'Vendor Emergency Contact Number',
            'vendor_website' => 'Vendor Website',
            'package_start_date' => 'Package Start Date',
            'package_end_date' => 'Package End Date',
            'vendor_delivery_charge' => 'Vendor Delivery Charge',
            'vendor_password' => 'Password',
            'vendor_status' => 'Vendor Status',
            'created_by' => 'Created By',
            'modified_by' => 'Modified By',
            'created_datetime' => 'Created Datetime',
            'modified_datetime' => 'Modified Datetime',
            'trash' => 'Trash',
        ];
    }
    
    /**   Relation function begin here
     * 
     *  
     * @return \yii\db\ActiveQuery
     */
    public function getSuborders()
    {
        return $this->hasMany(Suborder::className(), ['vendor_id' => 'vendor_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPackage()
    {
        return $this->hasOne(Package::className(), ['package_id' => 'package_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getImage()
    {
        return $this->hasOne(Image::className(), ['image_id' => 'image_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getVendorAddresses()
    {
        return $this->hasMany(VendorAddress::className(), ['vendor_id' => 'vendor_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getVendorBlockedDates()
    {
        return $this->hasMany(VendorBlockedDate::className(), ['vendor_id' => 'vendor_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getVendorDeliveryAreas()
    {
        return $this->hasMany(VendorDeliveryArea::className(), ['vendor_id' => 'vendor_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getVendorDeliveryTimeslots()
    {
        return $this->hasMany(VendorDeliveryTimeslot::className(), ['vendor_id' => 'vendor_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getVendorItems()
    {
        return $this->hasMany(VendorItem::className(), ['vendor_id' => 'vendor_id']);
    }   
     
    /*
     *  Relation functions END here
     */
		
	
     
     /** INCLUDE USER LOGIN VALIDATION FUNCTIONS**/
        /**
     * @inheritdoc
     */
    public static function findIdentity($id)
    {
        return static::findOne($id);
    }

    /**
     * @inheritdoc
     */
/* modified */
    public static function findIdentityByAccessToken($token, $type = null)
    {
          return static::findOne(['access_token' => $token]);
    }
 
/* removed
    public static function findIdentityByAccessToken($token)
    {
        throw new NotSupportedException('"findIdentityByAccessToken" is not implemented.');
    }
*/
    /**
     * Finds user by username
     *
     * @param  string      $username
     * @return static|null
     */
    public static function findByUsername($email)
    {
        return static::findOne(['vendor_contact_email' => $email]);        
    }
    
    public function findById($email)
    {
       return Vendor::find()->select('vendor_id')->where(['vendor_contact_email' => $email])->one();
    }

    /**
     * Finds user by password reset token
     *
     * @param  string      $token password reset token
     * @return static|null
     */
    public function findByPasswordResetToken($token)
    {
        $expire = \Yii::$app->params['user.passwordResetTokenExpire'];
        $parts = explode('_', $token);
        $timestamp = (int) end($parts);
        if ($timestamp + $expire < time()) {
            // token expired
            return null;
        }

        return static::findOne([
            'password_reset_token' => $token
        ]);
    }

    /**
     * @inheritdoc
     */
    public function getId()
    {
        return $this->getPrimaryKey();
    }

    /**
     * @inheritdoc
     */
    public function getAuthKey()
    {
        return $this->auth_key;
    }

    /**
     * @inheritdoc
     */
    public function validateAuthKey($authKey)
    {
        return $this->getAuthKey() === $authKey;
    }

    /**
     * Validates password
     *
     * @param  string  $password password to validate
     * @return boolean if password provided is valid for current user
     */
    public function validatePassword($passwords)
    {		
          return  Yii::$app->getSecurity()->validatePassword($passwords, $this->vendor_password);
              
    }

    /**
     * Generates password hash from password and sets it to the model
     *
     * @param string $password
     */
    public function setPassword($password)
    {
        $this->vendor_password = Yii::$app->getSecurity()->generatePasswordHash($this->vendor_password);
    }

    /**
     * Generates "remember me" authentication key
     */
    public function generateAuthKey()
    {
        $this->auth_key = Security::generateRandomKey();
    }

    /**
     * Generates new password reset token
     */
    public function generatePasswordResetToken()
    {
        $this->password_reset_token = Security::generateRandomKey() . '_' . time();
    }

    /**
     * Removes password reset token
     */
    public function removePasswordResetToken()
    {
        $this->password_reset_token = null;
    }
    /** EXTENSION MOVIE * */
    
    public function beforeSave($insert) 
	{
		if(isset($this->vendor_password))
		{
			$this->vendor_password = Yii::$app->getSecurity()->generatePasswordHash($this->vendor_password);			
			return parent::beforeSave($insert);
		}
		else
		{
			return false;
		}
	}
	    public static function loadvendorname()
	{       
			$vendorname= Vendor::find()
			->where(['!=', 'vendor_status', 'Deactive'])
			->where(['!=', 'trash', 'Deleted'])
			->all();
			$vendorname=ArrayHelper::map($vendorname,'vendor_id','vendor_name');
			return $vendorname;
	}	
	    public static function statusImageurl($status)
	{			
		if($status == 'Active')		
		return \Yii::$app->params['appImageUrl'].'active.png';
		return \Yii::$app->params['appImageUrl'].'inactive.png';
	}
    
}
