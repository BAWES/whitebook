<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "whitebook_customer".
 *
 * @property string $customer_id
 * @property string $customer_name
 * @property string $customer_email
 * @property string $customer_password
 * @property string $customer_dateofbirth
 * @property string $customer_gender
 * @property string $customer_mobile
 * @property string $customer_last_login
 * @property string $customer_ip_address
 * @property integer $created_by
 * @property string $modified_by
 * @property integer $created_date
 * @property string $modified_date
 * @property string $trash
 *
 * @property CustomerAddress[] $customerAddresses
 * @property CustomerCart[] $customerCarts
 * @property FeatureEvent[] $featureEvents
 * @property Order[] $orders
 */
class Customer extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'whitebook_customer';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['customer_name', 'customer_email', 'customer_password', 'customer_mobile','customer_gender'], 'required'],
            [['customer_dateofbirth', 'customer_last_login', 'created_by', 'modified_by', 'created_date', 'modified_date', 'trash'], 'safe'],
            [['created_by', 'created_date'], 'integer'],
            [['trash'], 'string'],
            [['customer_name', 'customer_email', 'customer_password', 'customer_mobile', 'customer_ip_address'], 'string', 'max' => 128],
            [['customer_gender'], 'string', 'max' => 64]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'customer_id' => ' ID',
            'customer_name' => 'Customer Name',
            'customer_email' => 'Email',
            'customer_password' => 'Password',
            'customer_dateofbirth' => 'Date Of Birth',
            'customer_gender' => 'Gender',
            'customer_mobile' => 'Mobile',
            'customer_last_login' => 'Last Login',
            'customer_ip_address' => 'Ip Address',
            'created_by' => 'Created By',
            'modified_by' => 'Modified By',
            'created_date' => 'Created Date',
            'modified_date' => 'Modified Date',
            'trash' => 'Trash',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCustomerAddresses()
    {
        return $this->hasMany(CustomerAddress::className(), ['customer_id' => 'customer_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCustomerCarts()
    {
        return $this->hasMany(CustomerCart::className(), ['customer_id' => 'customer_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getFeatureEvents()
    {
        return $this->hasMany(FeatureEvent::className(), ['customer_id' => 'customer_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getOrders()
    {
        return $this->hasMany(Order::className(), ['customer_id' => 'customer_id']);
    }
    
    
    public static function statusImageurl($img_status)
	{			
		if($img_status == 'Active')		
		return \Yii::$app->params['appImageUrl'].'active.png';
		return \Yii::$app->params['appImageUrl'].'inactive.png';
	}
}
