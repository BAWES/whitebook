<?php

namespace backend\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use backend\models\Imageresize;

/**
 * ImageresizeSearch represents the model behind the search form about `backend\models\Imageresize`.
 */
class ImageresizeSearch extends Imageresize
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'logo_width', 'logo_height', 'favicon_width', 'favicon_height', 'noimage_width', 'noimage_height', 'created_by', 'modified_by'], 'integer'],
            [['created_datetime', 'modified_datetime', 'trash'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Imageresize::find();

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        $query->andFilterWhere([
            'id' => $this->id,
            'logo_width' => $this->logo_width,
            'logo_height' => $this->logo_height,
            'favicon_width' => $this->favicon_width,
            'favicon_height' => $this->favicon_height,
            'noimage_width' => $this->noimage_width,
            'noimage_height' => $this->noimage_height,
            'created_by' => $this->created_by,
            'modified_by' => $this->modified_by,
            'created_datetime' => $this->created_datetime,
            'modified_datetime' => $this->modified_datetime,
        ]);

        $query->andFilterWhere(['like', 'trash', $this->trash]);

        return $dataProvider;
    }
}
