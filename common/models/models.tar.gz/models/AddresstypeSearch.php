<?php

namespace backend\models;

use Yii;
use yii\base\Model;
use backend\models\Addresstype;
use backend\models\AddresstypeSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\db\Query;
use yii\base;
use yii\data\ActiveDataProvider;

/**
 * AddresstypeSearch represents the model behind the search form about `backend\models\Addresstype`.
 */
class AddresstypeSearch extends Addresstype
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
           // [['type_id', 'created_by', 'modified_by'], 'integer'],
           // [['type_name', 'created_date', 'modified_date', 'trash'], 'safe'],
            [['type_name'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
		$query = Addresstype::find()
        ->where(['!=', 'trash', 'Deleted'])
		->orderBy('type_id');
		
       /* $query = Addresstype::find();
      //  $query = Addresstype::find()->where(['trash'=="Deleted",])->all();*/
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);
        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to any records when validation fails
             $query->where('trash'!="Deleted");
            return $dataProvider;
        }

      /*  $query->andFilterWhere([
			
            'type_id' => $this->type_id,
            'created_by' => $this->created_by,
            'modified_by' => $this->modified_by,
            'created_date' => $this->created_date,
            'modified_date' => $this->modified_date,
        ]);*/

         $query->andFilterWhere(['like', 'type_name', $this->type_name]);
           //->andFilterWhere(['like', 'trash', $this->trash]);
            //print_r ($dataProvider);exit;
            
            
        return $dataProvider;
    }
}
