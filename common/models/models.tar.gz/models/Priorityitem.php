<?php

namespace backend\models;
use Yii;

/**
 * This is the model class for table "whitebook_priority_item".
 *
 * @property string $priority_id
 * @property string $item_id
 * @property string $priority_level
 * @property string $priority_start_date
 * @property string $priority_end_date
 * @property integer $created_by
 * @property integer $modified_by
 * @property string $created_datetime
 * @property string $modified_datetime
 * @property string $trash
 *
 * @property VendorItem $item
 */
class Priorityitem extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
     
    public static function tableName()
    {
        return 'whitebook_priority_item';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['item_id', 'vendor_id', 'category_id', 'subcategory_id', 'priority_start_date', 'priority_end_date', 'priority_level'], 'required'],
            [['item_id', 'created_by', 'modified_by'], 'integer'],
            [['priority_level', 'trash'], 'string'],
            [['priority_start_date', 'priority_end_date', 'created_datetime', 'modified_datetime'], 'safe']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'priority_id' => 'Priority ID',
            'item_id' => 'Item ID',
            'priority_level' => 'Defines the priority level',
            'priority_start_date' => 'Priority Start Date',
            'priority_end_date' => 'Priority End Date',
            'created_by' => 'Created By',
            'modified_by' => 'Modified By',
            'created_datetime' => 'Created Datetime',
            'modified_datetime' => 'Modified Datetime',
            'trash' => 'Trash',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getItem()
    {
        return $this->hasOne(VendorItem::className(), ['item_id' => 'item_id']);
    }
    
    public static function getItemName($id)
    {		
		$model = Vendoritem::find()->where(['item_id'=>$id])->one();
        return $model->item_name;
    }
}
