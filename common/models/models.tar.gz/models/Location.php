<?php

namespace backend\models;
use yii\helpers\ArrayHelper;
use Yii;

/**
 * This is the model class for table "{{%location}}".
 *
 * @property integer $id
 * @property integer $country_id
 * @property integer $city_id
 * @property string $location
 *
 * @property City $city
 * @property Category $country
 */
class Location extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%location}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['country_id', 'city_id', 'location','status'], 'required'],
            [['country_id', 'city_id'], 'integer'],
            [['location'], 'string', 'max' => 50]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'country_id' => 'Country Name',
            'city_id' => 'City Name',
            'location' => 'Location',
            'status'=>'Status',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCity()
    {
        return $this->hasOne(City::className(), ['city_id' => 'city_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCountry()
    {
        return $this->hasOne(Country::className(), ['country_id' => 'country_id']);
    }
    
    public static function statusImageurl($status)
	{			
		if($status == 'Active')		
		return \Yii::$app->params['appImageUrl'].'active.png';
		return \Yii::$app->params['appImageUrl'].'inactive.png';
	}
	
	  	public static function loadlocation()
	{       
			$location= Location::find()
//			->where(['!=', 'status', 'Deactive'])
			->where(['!=', 'trash', 'Deleted'])
			->all();
			$location=ArrayHelper::map($location,'id','location');
			return $location;
	}		
	
	    	public static function locationdetails($id)
	{       
			$location= Location::find()
//			->where(['!=', 'status', 'Deactive'])
			->where(['!=', 'trash', 'Deleted'])
			->where(['=', 'id', $id])
			->all();
			$location=ArrayHelper::map($location,'id','location');
			return $location;
	}	
    public static function getlocation($id)
    {		
		$model = Location::find()->where(['id'=>$id])->one();
        return $model->location;
    }
}
